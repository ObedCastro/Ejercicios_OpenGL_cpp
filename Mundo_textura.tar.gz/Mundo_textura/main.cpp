#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <SOIL/SOIL.h>
#include <stdio.h>

 //Para rotar luces
int rotate_x = 0;
int rotate_y = 0;

//Para rotar planeta
int rotar_x = 0;
int rotar_y = 0;
int rotar_z = 0;

float Scale = 0.7;
float Scale_azul_amarilla = 0.4;
float Scale_verde = 0.45;
float Scale_roja = 0.35;

void Materiales(GLfloat amb1, GLfloat amb2, GLfloat amb3, GLfloat dif1, GLfloat dif2, GLfloat dif3, GLfloat spe1, GLfloat spe2, GLfloat spe3)
{
  GLfloat mat_ambient[] = { amb1, amb2, amb3, 1.0f };
  GLfloat mat_diffuse[] = { dif1, dif2, dif3, 1.0f };
  GLfloat mat_specular[] = { spe1, spe2, spe3, 1.0f };
  GLfloat mat_shininess[] = { 100.0f };

  glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
  glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
}

//Funciones de esferas con materiales
void Esfera_azul()
{	
	glPopMatrix();
	glPushMatrix();
		glTranslatef(-0.9, 0.8, -2.5);
		Materiales(0.0, 0.1, 0.06, 0.0, 0.50980392, 0.50980392, 0.50196078, 0.50196078, 0.50196078);
		glutSolidSphere(Scale_azul_amarilla, 100.0, 100.0);
	glPopMatrix();
	glPushMatrix();
}

void Esfera_verde()
{
	glPopMatrix();
	glPushMatrix();
		glTranslatef(0.2, 0.5, -2.5);
		Materiales(0.0215, 0.1745, 0.0215, 0.07568, 0.61424, 0.07568, 0.633, 0.727811, 0.633);
		glutSolidSphere(Scale_verde, 100.0, 100.0);
	glPopMatrix();
	glPushMatrix();
}

void Esfera_roja()
{
	glPopMatrix();
	glPushMatrix();
		glTranslatef(0.7, -0.3, -2.5);
		Materiales(0.1745, 0.01175, 0.01175, 0.61424, 0.04136, 0.04136, 0.727811, 0.626959, 0.625959);
		glutSolidSphere(Scale_roja, 100.0, 100.0);
	glPopMatrix();
	glPushMatrix();
}

void Esfera_amarilla()
{
	glPopMatrix();
	glPushMatrix();
		glTranslatef(-0.8, -0.7, -2.5);
		Materiales(0.24725, 0.1995, 0.0745, 0.75164, 0.60648, 0.22648, 0.628281, 0.555802, 0.366065);
		glutSolidSphere(Scale_azul_amarilla, 100.0, 100.0);
	glPopMatrix();
	glPushMatrix();
}

//Función que dibuja "la tierra" y aplica textura
void Planeta(void)
{		
	int width, height;  //tamaño de la imagen
	unsigned char* image = SOIL_load_image("mapa.bmp", &width, &height, 0, SOIL_LOAD_RGB); //carga la imagen
	
	//la pasa a texturas
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	
	// Indicamos el tipo de filtrado
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glPushMatrix();    
		GLUquadric *quad;
		quad = gluNewQuadric();
		glTranslatef(-0.5, 0.1, -2.0);
		gluQuadricTexture(quad, GL_TRUE);
		glEnable(GL_TEXTURE_2D);
			glRotatef(rotar_x, 1.0, 0.0, 0.0);
			glRotatef(rotar_y, 0.0, 1.0, 0.0);
			glRotatef(rotar_z, 0.0, 0.0, 1.0);
			glRotatef(-90, 1.0, 0.0, 0.0);
			glRotatef(90, 0.0, 0.0, 1.0);  
			gluSphere(quad, Scale, 100, 100);
		glDisable(GL_TEXTURE_2D);
    glPopMatrix();
    glutSwapBuffers();
}

//DIBUJA LA ESCENA
 //Limpiar los buffer
 //Activar luces
 //Posición inicial de las luces
 //Llamada a la función de cada figura
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
    glLoadIdentity();     
    
    glShadeModel (GL_SMOOTH);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
    GLfloat light_position[] = { 1.0, 0.5, 1.0, 0.0 }; 
      
    glRotated (rotate_x, 1.0, 0.0, 0.0);
    glRotated (rotate_y, 0.0, 1.0, 0.0);	 
	
    glLightfv (GL_LIGHT0, GL_POSITION, light_position);
    
    Esfera_azul();   
    Esfera_verde();    
    Esfera_roja();    
    Esfera_amarilla();
    Planeta(); 
    
    glFlush();
	glutSwapBuffers();
}

//Recalcula el tamaño
void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 0.5, 20.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

//Controla la posición de las luces
void specialKeys( int key, int x, int y )
{
	if (key == GLUT_KEY_RIGHT) {rotate_y += 7;}		
	if (key == GLUT_KEY_LEFT) {rotate_y -= 7;}		
	if (key == GLUT_KEY_UP) {rotate_x += 7;}		
	if (key == GLUT_KEY_DOWN) {rotate_x -= 7;}		
	glutPostRedisplay();
}

//Controla el movimiento y escalado del planeta son los números en el rango (1-6)
void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
		case 52: rotar_y += 7; break; //4	
		case 49: rotar_y -= 7; break; //1		
		case 50: rotar_x += 7; break; //2	
		case 53: rotar_x -= 7; break; //5	
		case 51: rotar_z += 7; break; //3	
		case 54: rotar_y -= 7; break; //6		
		case 'X': Scale += 0.05; break;
		case 'x': Scale -= 0.05; break;
		
		case 't':
			Scale -= 0.05;
			Scale_azul_amarilla -= 0.02;
			Scale_roja -= 0.02;
			Scale_verde -= 0.02;
		break;
		case 'T':
			Scale += 0.05;
			Scale_azul_amarilla += 0.02;
			Scale_roja += 0.02;
			Scale_verde += 0.02;
		break;
	}
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(1000, 600);
   glutInitWindowPosition(100, 100);
   glutCreateWindow("Mundo");
   glutDisplayFunc(display);
   glutSpecialFunc(specialKeys);
   glutKeyboardFunc(keyboard);
   glutReshapeFunc(reshape);
   glutMainLoop();
   return 0;
}
